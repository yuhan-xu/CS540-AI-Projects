"""
Name: Yuhan Xu
Email: yxu329@wisc.edu
Class: CS 540
Project name: ice_cover.py
"""


import csv
import math
import random


"""
takes no arguments and returns the data as described below in an n-by-2 array
@:param no parameters
@:return returns the data as described below in an n-by-2 array
"""
def get_dataset():
    overall_list = []
    with open('data.csv', encoding='utf-8-sig', mode='r') as csvfile:
        reader = csv.reader(csvfile)
        # loop through each line in reader and append it to the overall_list
        for line in reader:
            overall_list.append(line)
        new_overall = []
        # for each element in overall_list, use list comprehension to convert every term in element to int and append
        # changed element to new_overall list
        for element in overall_list:
            new_element = [int(i) for i in element]
            new_overall.append(new_element)

    return new_overall


"""
takes the dataset as produced by the previous function and prints several statistics about the data; does not return 
anything
@:param dataset
prints several statistics about the data, including length of the dataset, its average, and its standard deviation
"""
def print_stats(dataset):
    length = len(dataset)  # get the length of the dataset
    total_sum = 0

    # calculate the sum, and then compute the average
    for element in dataset:
        total_sum += element[1]
    avg = total_sum / length
    new_sum = 0
    # calculate the standard deviation
    for element in dataset:
        num = (element[1] - avg)**2
        new_sum += num
    sd = math.sqrt(new_sum / (length-1))

    print(length)

    list1 = [avg, sd]
    # print rounded average and rounded standard deviation
    for i in list1:
        print("%.2f" % round(i, 2))


"""
calculates and returns the mean squared error on the dataset given fixed betas
@:param beta_0, beta_1, dataset = get_dataset()
@:return returns the mean squared error on the dataset given fixed betas
"""
def regression(beta_0, beta_1, dataset = get_dataset()):
    tot_sum = 0
    # calculate the mean squared error on the dataset given fixed betas
    for element in dataset:
        value = (beta_0 + beta_1*element[0] - element[1])**2
        tot_sum += value
    result = tot_sum / (len(dataset))  # calculate the mean squared error on the dataset given fixed betas
    return result


"""
This function will perform gradient descent on the MSE. At the current parameter (beta_0, beta_1), the gradient is 
defined by the vector of partial derivatives
@:param beta_0, beta_1, dataset = get_dataset()
@:return returns the corresponding gradient as a tuple with the partial derivative with respect to beta_0 as the first
value and the partial derivative with respect to beta_1 as the second value
"""
def gradient_descent(beta_0, beta_1, dataset = get_dataset()):
    tot_sum = 0
    for element in dataset:
        value = beta_0 + beta_1*element[0] - element[1]
        tot_sum += value
    result1 = (tot_sum * 2) / (len(dataset))  # get the partial derivative with respect to beta_0

    tot_sum1 = 0
    for element1 in dataset:
        value1 = (beta_0 + beta_1*element1[0] - element1[1]) * element1[0]
        tot_sum1 += value1
    result2 = (tot_sum1 * 2) / (len(dataset))  # get the partial derivative with respect to beta_1

    return result1, result2


"""
performs T iterations of gradient descent starting at (beta_0, beta_1) = (0,0) with the given parameter and prints the 
results; does not return anything
@:param T, eta
print number of iteration, current beta_0 and beta_1 values, and current MSE
"""
def iterate_gradient(T, eta):
    # define beta_0 and beta_1 to be lists with only 0.0
    beta_0 = [0.0]
    beta_1 = [0.0]
    # iterate T times to get beta_0, beta_1, and MSE
    for i in range(T):
        new_beta_0 = beta_0[i] - eta * gradient_descent(beta_0[i], beta_1[i])[0]
        new_beta_1 = beta_1[i] - eta * gradient_descent(beta_0[i], beta_1[i])[1]
        beta_0.append(new_beta_0)
        beta_1.append(new_beta_1)
        # print number of iteration and the rounded values
        print(str(i + 1) + " " + str("%.2f" % new_beta_0) + " " + str("%.2f" % new_beta_1) + " " +
              str("%.2f" % regression(new_beta_0, new_beta_1)))


"""
using the closed-form solution, calculates and returns the values of beta_0 beta_1 and the corresponding MSE as a 
three-element tuple
@:param no parameters
@:return returns the values of beta_0 beta_1 and the corresponding MSE as a three-element tuple
"""
def compute_betas():
    dataset = get_dataset()
    # calculate the average of x
    x_sum = 0
    for element in dataset:
        x_sum += element[0]
    x_bar = x_sum / len(dataset)

    # calculate the average of y
    y_sum = 0
    for element1 in dataset:
        y_sum += element1[1]
    y_bar = y_sum / len(dataset)

    # this step is used to compute beta1
    numerator = 0
    denominator = 0
    for each in dataset:
        value1 = (each[0] - x_bar) * (each[1] - y_bar)
        value2 = (each[0] - x_bar)**2
        numerator += value1
        denominator += value2
    beta_1_hat = numerator / denominator  # get beta1
    beta_0_hat = y_bar - (beta_1_hat * x_bar)  # get beta0
    mse = regression(beta_0_hat, beta_1_hat)  # compute mse using beta0 and beta1

    return beta_0_hat, beta_1_hat, mse


"""
using the closed-form solution betas, return the predicted number of ice days for that year
@:param year
@:return return the predicted number of ice days for that year
"""
def predict(year):
    predicted = compute_betas()[0] + compute_betas()[1] * year  # predict number of ice day for a given year
    #predicted = "%.2f" % predicted
    return predicted


"""
normalizes the data before performing gradient descent, prints results as in function 5
@:param T, eta
print print results as in function 5 which is iterate_gradient(T, eta)
"""
def iterate_normalized(T, eta):
    dataset = get_dataset()
    # calculate the average of x
    x_sum = 0
    for element in dataset:
        x_sum += element[0]
    x_bar = x_sum / len(dataset)

    # calculate standard deviation of x
    t_sum = 0
    for element1 in dataset:
        value = (element1[0] - x_bar)**2
        t_sum += value
    std_x = math.sqrt(t_sum / (len(dataset)-1))

    # modify each xi in the dataset
    for element2 in dataset:
        element2[0] = (element2[0] - x_bar) / std_x

    # the following code is similar to the function iterate_gradient
    current_beta_0 = 0
    current_beta_1 = 0

    t = 1
    while t <= T:
        current_beta_0 = current_beta_0 - eta * gradient_descent(current_beta_0, current_beta_1, dataset)[0]
        current_beta_1 = current_beta_1 - eta * gradient_descent(current_beta_0, current_beta_1, dataset)[1]
        reg_value = "%.2f" % regression(current_beta_0, current_beta_1, dataset)
        print(str(t) + " " + str("%.2f" % current_beta_0) + " " + str("%.2f" % current_beta_1) + " " + str(reg_value))
        t = t + 1


"""
performs stochastic gradient descent. Modify the gradient as follows: in iteration t, randomly pick ONE of the n items, 
and approximate the gradient using only that item.
@:param T, eta
print results as in function 5 which is iterate_gradient(T, eta)
"""
def sgd(T, eta):
    dataset = get_dataset()

    # get the average of x
    x_sum = 0
    for element in dataset:
        x_sum += element[0]
    x_bar = x_sum / len(dataset)

    # get standard deviation of x
    t_sum = 0
    for element1 in dataset:
        value = (element1[0] - x_bar) ** 2
        t_sum += value
    std_x = math.sqrt(t_sum / (len(dataset) - 1))

    # modify each xi in the dataset
    for i in range(len(dataset)):
        dataset[i][0] = (dataset[i][0] - x_bar) / std_x

    beta_0 = 0
    beta_1 = 0

    # iterate T times
    for i in range(T):
        # generate a random number between 0 and len(dataset) - 1
        random_num = random.randint(0, len(dataset) - 1)
        # choose a random x-y pair in the dataset using the random number generated
        choose_random = dataset[random_num]
        gradient1 = 2 * (beta_0 + (beta_1 * choose_random[0]) - choose_random[1])
        gradient2 = 2 * (beta_0 + (beta_1 * choose_random[0]) - choose_random[1]) * choose_random[0]
        # use the formula to get beta_0 and beta_1
        beta_0 = beta_0 - eta * gradient1
        beta_1 = beta_1 - eta * gradient2
        # print the number of iteration and rounded values
        print(str(i + 1) + " " + str("%.2f" % beta_0) + " " + str("%.2f" % beta_1) + " " + str(
            "%.2f" % regression(beta_0, beta_1, dataset)))












